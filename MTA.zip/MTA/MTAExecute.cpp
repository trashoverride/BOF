/*
 * MTAExecute.cpp
 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#include "MTAExecute.h"

MTAExecute::MTAExecute() {
	// TODO Auto-generated constructor stub

}

MTAExecute::~MTAExecute() {
	// TODO Auto-generated destructor stub
}


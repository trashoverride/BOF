/*
 * MTA.h
 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#ifndef MTA_H_
#define MTA_H_

#include "Threadable.h"
#include "MTAExecute.h"
#include "MTAArquivo.h"
#include <vector>
#include <list>

class MTA :public TriadCore::Threadable<MTAArquivo>{
public:
	MTA(bool DeleteJobs);
	virtual ~MTA();
	bool processJob(MTAArquivo *job);
	void startThreads();
	void assignThreadJobs();



};

#endif /* MTA_H_ */

g++ -c -fpermissive Mutex.cpp
g++ -c -fpermissive MTAExecute.cpp
g++ -c -fpermissive MTA.cpp
#g++ -c -fpermissive main.cpp
g++ -c -fpermissive MTAArquivo.cpp
g++ Mutex.o MTA.o MTAExecute.o  MTAArquivo.o -pthread -o MTA

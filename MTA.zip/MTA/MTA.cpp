/*
 * MTA.cpp
 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#include "Threadable.h"
#include "MTA.h"
#include "MTAExecute.h"
#include <vector>
#include <list>


vector<MTAArquivo *>arquivos;
vector<MTA*> ListaThreads;
bool m_bSucesso;



MTA::MTA(bool DeleteJobs):Threadable<MTAArquivo>(DeleteJobs){
	// TODO Auto-generated constructor stub

}

MTA::~MTA() {
	// TODO Auto-generated destructor stub
}

bool MTA::processJob(MTAArquivo *job)
{
	int i = 0;
	while (i < 1000)
	{
			std::cout << job->nome.c_str()<< std::endl;
			//std::cout <<i << std::endl;
			i++;
	}
	sleep(1);
	return true;

}


void MTA::assignThreadJobs()
{
	//Iterate over all input dirs
	unsigned int size = arquivos.size();

	for (unsigned int i = 0; i < size; ++i)
	{
		ListaThreads[i]->addJob(arquivos[i]);
	}

}



void startThreads()
{
	size_t size = ListaThreads.size();
	for (unsigned int i = 0; i < size; ++i)
	{
		ListaThreads[i]->start();
	}
}




void waitThreads()
{
	size_t size = ListaThreads.size();
	bool dontStop = true;
	m_bSucesso = true;

	while (dontStop)
	{
		dontStop = false;
		for (unsigned int i = 0; i < size; i++)
		{
			int items = ListaThreads[i]->getProcessedJobs() + ListaThreads[i]->getFailedJobs();

			if (items < ListaThreads[i]->getJobNumber())
			{
				dontStop = true;
				break;
			}
			else
			{
				if (ListaThreads[i]->getFailedJobs() && m_bSucesso)
					m_bSucesso = false;

				ListaThreads[i]->terminate();
			}
		}

		if (dontStop)
			sleep(1);
	}
	unsigned int nEncerradas = 0;
	while (nEncerradas != size)
	{
		nEncerradas = 0;
		for (unsigned int i = 0; i < size; i++)
		{
			if (ListaThreads[i]->encerrada())
			{
				nEncerradas++;
			}
		}
	}
}










int main(void)
{



	MTAArquivo * arq = new MTAArquivo();
	arq->nome = "teste";
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);
	arquivos.push_back(arq);



	std::cout << "Iniciando Threads..." << std::endl;

	try
	{

	//inclui threads na pilha
	for (int i = 0; i < 10; ++i)
	{
				MTA * mtaThread = new MTA(true);
				ListaThreads.push_back(mtaThread);
	}


	//add jobs as threads
	for (int i = 0; i < 10; ++i)
	{
					ListaThreads[i]->addJob(arquivos[i]);

	}

	//start threads
	startThreads();


	//wait threads
	// waitThreads();




	}catch (...)
		{

			return -1;
	}


}


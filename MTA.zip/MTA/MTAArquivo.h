/*
 * MTAArquivo.h

 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#ifndef MTAARQUIVO_H_
#define MTAARQUIVO_H_
#include <string>

using namespace std;

class MTAArquivo {
public:
	MTAArquivo();
	virtual ~MTAArquivo();
	string nome;
};

#endif /* MTAARQUIVO_H_ */

#include "Mutex.h"

#include <climits>

using namespace TriadCore;

/**
 * Construtor.
 *
 * Chama o mutex trylock e o unlock para forcar a inicializacao completa do mutex
 */

Mutex::Mutex( void ) :
	m_nAditionalLock( 0 ),
	m_nOwner( 0 ),
	m_nLocks( 0 )
{
	pthread_mutex_init( &m_oMutex, NULL );
	pthread_mutex_trylock( &m_oMutex );
	pthread_mutex_unlock( &m_oMutex );
}

/**
 * Destrutor
 */

Mutex::~Mutex( void )
{
	pthread_mutex_destroy( &m_oMutex );
}

/**
 * Chama o lock nao bloqueante do mutex, com uma verificacao adicional (double-check-locking)
 */

bool Mutex::lock( void )
{
	if ( m_nOwner == pthread_self( ) )
	{
		++m_nLocks;
		return true;
	}

	if ( m_nAditionalLock )
	{
		return false;
	}


	if ( pthread_mutex_trylock( &m_oMutex ) )
	{
		return false;
	}
	else
	{
		m_nAditionalLock = 0xDEADC0DE;
	}

	m_nOwner = pthread_self( );
	++m_nLocks;

	return true;
}

/**
 * Destrava o Mutex
 */

void Mutex::unlock( void )
{
	if ( m_nOwner != pthread_self( ) )
	{
		//TODO: throw de exception
	}

	if ( !m_nAditionalLock )
	{
		return;
	}

	if ( 0 >= --m_nLocks )
	{
		m_nAditionalLock = 0;
		m_nOwner = 0;
		m_nLocks = 0;
		pthread_mutex_unlock( &m_oMutex );
	}
}

/**
 * Faz o lock bloqueante da thread
 */

void Mutex::waitLock( void )
{
	if ( m_nOwner == pthread_self( ) )
	{
		++m_nLocks;
		return;
	}

	pthread_mutex_lock( &m_oMutex );
	m_nAditionalLock = 0xDEADC0DE;
	m_nOwner = pthread_self( );
	++m_nLocks;
}

/*
 * MTAArquivo.cpp
 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#include "MTAArquivo.h"

MTAArquivo::MTAArquivo() {
	// TODO Auto-generated constructor stub

}

MTAArquivo::~MTAArquivo() {
	// TODO Auto-generated destructor stub
}


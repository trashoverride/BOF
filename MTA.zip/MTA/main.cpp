#include "Threadable.h"
#include "MTAExecute.h"
#include "MTA.h"
#include <vector>


vector<MTA*> ListaThreads;

int main(void)
{




	std::cout << "Iniciando Threads..." << std::endl;
	for (int i = 0; i < 10; ++i)
	{
				MTA * mtaThread = new MTA(true);
				ListaThreads.push_back(mtaThread);
	}








}




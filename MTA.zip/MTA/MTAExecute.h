/*
 * MTAExecute.h
 *
 *  Created on: 26/05/2013
 *      Author: neo
 */

#ifndef MTAEXECUTE_H_
#define MTAEXECUTE_H_

class MTAExecute {
public:
	MTAExecute();
	virtual ~MTAExecute();
};

#endif /* MTAEXECUTE_H_ */

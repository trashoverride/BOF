#ifndef __MUTEX_H__
#define __MUTEX_H__

#include <pthread.h>

namespace TriadCore
{

/**
 * Classe de mutex
 */
class Mutex
{
public:
	Mutex( void );
	~Mutex( void );

	bool	lock( void );
	void	unlock( void );
	void	waitLock( void );

private:
	volatile long	m_nAditionalLock;
	pthread_mutex_t	m_oMutex;
	pthread_t		m_nOwner;
	long			m_nLocks;
};


/**
 * Classe de facilitacao de acesso a mutex
 */

template < class Class >
class MutexedClass : public Mutex, public Class
{
public:
	/// Construtor
	MutexedClass( void ) : Mutex( ), Class( ) { };

	/// Destrutor
	virtual ~MutexedClass( void ) { };
};

}

#endif // __MUTEX_H__

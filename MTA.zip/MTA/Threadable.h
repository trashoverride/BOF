#ifndef __THREADABLE_H__
#define __THREADABLE_H__

//#include "Base/CoreException.h"
//#include "Utils/Log.h"
#include "Mutex.h"


#include <exception>
#include <list>
#include <unistd.h>
#include <iostream>

using namespace std;

//#define TH_DEBUG
namespace TriadCore
{
	template<typename T>
	class Threadable
	{
		protected:
			///Jobs removed from the list
			bool m_bDeleteJobs;

			///Run thread shold exit
			bool m_bTerminate;

			///Jobs that couldn't be processed properly
			long m_nFailedJobs;

			///Number of Jobs processed
			long m_nProcessedJobs;

			///List of jobs
			list<T*> m_oJobList;

			///Mutex used to control the access to the list of jobs
			Mutex m_oJobMutex;

			///Thread objetc where the Run method will execute
			pthread_t m_oThreadId;

			typename list<T*>::iterator m_pNextjob;
			bool m_bIteratorIsInitialized;
			bool m_bEncerrada;
			long m_nNumeroJobs;

		public:

			Threadable(bool DeleteJobs);
			virtual ~Threadable();
			void addJob(T *Job);

			long getFailedJobs();
			long getProcessedJobs();
			void terminate();
			bool encerrada();

			virtual bool processJob(T *Job) = 0;

			long getJobNumber();
			long getJobCurrentNumber();
			void run();
			int start();

		protected:
			//virtual void	handleException( CoreException& p_oException ) = 0;
			//virtual void	handleException( std::exception& p_oException ) = 0;

		private:
			static void *ThreadCallback(void *ThreadableRef);

			typename list<T*>::iterator getJob();
			void goNextJob();
			bool threadablePass;
	        void *tret;

	};

/**
* Constructor
* @param DeleteJobs when true, true jobs will be erased from the job list after processed
*/
template<typename T>Threadable<T>::Threadable(bool DeleteJobs):
	m_bDeleteJobs(DeleteJobs),
	m_bTerminate(false),
	m_nFailedJobs(0),
	m_nProcessedJobs(0),
	m_bIteratorIsInitialized(false),
	m_bEncerrada(false),
	m_nNumeroJobs(0),
	threadablePass(false)
	//m_pNextjob(0)
{
	m_pNextjob = m_oJobList.end();
}
/**
* Destructor
*/
template<typename T>Threadable<T>::~Threadable()
{
	int err = pthread_join(m_oThreadId, &tret);
	 if ( err != 0 )
		 std::cout << "Nao esperou a thread";

	if(m_bDeleteJobs)
	{
		m_oJobMutex.waitLock();
		m_pNextjob = m_oJobList.begin();
		while( m_pNextjob != m_oJobList.end() )
		{
			delete *m_pNextjob;
		}
		m_oJobList.clear();
		m_oJobMutex.unlock();
	}
}

template<typename T> bool Threadable<T>::encerrada(){return m_bEncerrada;}

/**
* Adds a new job to the job list
* @param Pointer to an object that will be used in the processJob
*/
template<typename T> void Threadable<T>::addJob(T *Job)
{
	//if the member variable m_bTerminate is changed to true and
	//we are in the middle of an execution, we wait until the thread
	//finishes its execution before destroy the thread object
	m_oJobMutex.waitLock();

	m_oJobList.push_back(Job);
	m_nNumeroJobs++;

	m_oJobMutex.unlock();
}

/**
 * @return the number of failed jobs
 */
template<typename T>long Threadable<T>::getFailedJobs() {return m_nFailedJobs;}
/**
 * @return the number of successfully processed jobs
 */
template<typename T>long Threadable<T>::getProcessedJobs(){return m_nProcessedJobs;}
/**
 * Changes the m_bTerminate member to true stopping the thread
 */
template<typename T>void Threadable<T>::terminate() {m_bTerminate = true;}

/**
* Gets the number of jobs in the job list
* @return the current size of the job list
*/
template<typename T> long Threadable<T>::getJobNumber()
{
/*
	m_oJobMutex.waitLock();

	long size = m_oJobList.size();

	m_oJobMutex.unlock();
*/
	return m_nNumeroJobs;
}
template<typename T> long Threadable<T>::getJobCurrentNumber()
{
	return m_oJobList.size();
}

/**
* Static function used as a parameter to the pthread_crate
* This function calls the run method from the object that created
* the thread (Threadable class)
* @param ThreadableRef is a pointer to the Threadable class itself
*/
template<typename T> void * Threadable<T>::ThreadCallback(void *ThreadableRef)
{
	if(ThreadableRef)
	{
		Threadable *ptr = (Threadable *)ThreadableRef;
		ptr->run();
	}
	return (void*)0;
}

/**
* This method process all the jobs in the job list calling the implementation
* of the virtual processJob method and continues to execute
* while jobToProcess == true.
*/
template<typename T> void Threadable<T>::run()
{
	try
	{
		//list<T>::iterator job;
		//list<T>::const_iterator job;
		typename list<T*>::iterator job;

		while(!this->m_bTerminate)
		{
			//bool jobToProcess = false;

			//#ifdef TH_DEBUG
			//cout << "\nList size: " << this->m_oJobList.size() << "\n";
			//#endif


			job = getJob();
			if( job != m_oJobList.end() )
			{
				// para nao errar na contagem por exceptions nao tratadas
				try
				{
					processJob(*job) == true ? m_nProcessedJobs++ : m_nFailedJobs++;

				}
				/*catch (TriadCore::CoreException &ex)
				{
					m_nFailedJobs++; // se houve exception nao tratada o processo falhou
					//LOG_DEBUG_OUT(ex.getFullDescription().c_str());
					//LOG_DEBUG_OUT("[Threadable<T>::run] TriadCore::CoreException nao tratada!");
				}*/
				catch (std::exception &e)
				{
					m_nFailedJobs++; // se houve exception nao tratada o processo falhou
					//LOG_DEBUG_OUT(e.what());
					//LOG_DEBUG_OUT("[Threadable<T>::run] std::exception nao tratada!");
				}
				catch (...)
				{
					m_nFailedJobs++; // se houve exception nao tratada o processo falhou
					//LOG_DEBUG_OUT("[Threadable<T>::run] exception nao tratada!");
				}

				goNextJob();

				if(m_bDeleteJobs)
				{
					m_oJobMutex.waitLock();
					m_oJobList.pop_front();
					m_oJobMutex.unlock();
					delete *job;
				}

			}
			else
			{
				m_bIteratorIsInitialized = false;
				usleep(1);
			}
		}

		if( m_nFailedJobs > 0 )
		{
			//TriadCore::Log::getInstance()->registrarErro( __FILE__, __LINE__, "Vou mudar o nome para extensao com Erro" );
			//TriadCore::Log::getInstance()->atualizaExtensaoLogComErr();
		}
		else
		{
			//TriadCore::Log::getInstance()->registrarErro( __FILE__, __LINE__, "Vou mudar o nome para extensao com OK" );
			//TriadCore::Log::getInstance()->atualizaExtensaoLogComOk();
		}

		//TriadCore::Log::getInstance()->close();

	}
	/*catch ( CoreException& e )
	{
		handleException( e );
		//TriadCore::Log::getInstance()->registrarErro( __FILE__, __LINE__, "Vou mudar o nome para extensao com Erro 2" );
		TriadCore::Log::getInstance()->atualizaExtensaoLogComErr();
		TriadCore::Log::getInstance()->close();
	}*/
	catch ( std::exception& e )
	{
		//handleException( e );
		//TriadCore::Log::getInstance()->registrarErro( __FILE__, __LINE__, "Vou mudar o nome para extensao com Erro 3" );
		//TriadCore::Log::getInstance()->atualizaExtensaoLogComErr();
		//TriadCore::Log::getInstance()->close();
	}
	m_bEncerrada = true;
}

/**
* When the job list is empty, this function waits until a new item incomes
* or the thread terminates. It will return the first list item or the current one.
* The m_pNextjob iterator should be incremented outside this function (call goNextJob for this)
* (after the processJop method returns). The goal is to avoid to erase the
* the current node while it is being pointed by m_pNextjob.
* @return an iterator pointing to the current job in the list
*/
template<typename T> typename list<T*>::iterator Threadable<T>::getJob()
{
	bool listWasEmpty = m_oJobList.empty();

	while(m_oJobList.empty() && !m_bTerminate)
		usleep(10);

	if(m_bTerminate)
		return m_oJobList.end();

	if(listWasEmpty || !m_bIteratorIsInitialized /*m_pNextjob == 0*/)
	{
		m_pNextjob = m_oJobList.begin();
		if( !m_bDeleteJobs )
		{
			int size = m_nProcessedJobs + m_nFailedJobs;
			for(int i = 0; i < size; i++, m_pNextjob++);
		}
		m_bIteratorIsInitialized = true;
	}

	return m_pNextjob;
}

/**
* Just increments the member m_pNextjob to point to the next
* item in the m_oJobList list (or to point to the end of the list)
*/
template<typename T> void Threadable<T>::goNextJob()
{
	++m_pNextjob;
}

/**
* Start the thread that will process all the jobs in the job list
* @return the result of the pthread_create function
*/
template<typename T> int Threadable<T>::start()
{
	return pthread_create(&m_oThreadId, NULL, ThreadCallback, this);
}

}

#endif



